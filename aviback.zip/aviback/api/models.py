from django.db import models

#
# class Company(models.Model):
#     name = models.CharField(max_length=300)
#     desc = models.TextField(default='some text')
#     city = models.CharField(max_length=100, default='Almaty')
#     address = models.TextField(default='Tole bi, 59')
#
#     def short(self):
#         return {
#             'id': self.id,
#             'name': self.name,
#             'city': self.city
#         }
#
#     def full(self):
#         return {
#             'id': self.id,
#             'name': self.name,
#             'city': self.city,
#             'description': self.desc,
#             'address': self.address
#         }


class City(models.Model):
    name = models.CharField(max_length=200)
    country = models.CharField(max_length=200)
    airport_name = models.CharField(max_length=200)

    def short(self):
        return {
            'name': self.name,
            'country': self.country,
        }

    def full(self):
        return {
            'id': self.id,
            'name': self.name,
            'country': self.country,
            'airport_name': self.airport_name
        }


class Ticket(models.Model):
    from_city = models.ForeignKey(City, on_delete=models.CASCADE, related_name='from_city')
    to_city = models.ForeignKey(City, on_delete=models.CASCADE, related_name='to_city')
    price = models.FloatField()

    # def full(self):
    #     return {
    #         'id': self.id,
    #         'from_city': self.from_city,
    #         'to_city': self.to_city,
    #         'price': self.price
    #     }


# class User(models.Model):
#     name = models.CharField(max_length=100)
#     login = models.CharField(max_length=200)
#     password = models.IntegerField()
#
#     def full(self):
#         return {
#             'id': self.id,
#             'name': self.name,
#             'login': self.login,
#             'password': self.password
#         }


# class Vacancy(models.Model):
#     name = models.CharField(max_length=100)
#     desc = models.TextField()
#     salary = models.FloatField()
#     company = models.ForeignKey(Company, on_delete=models.CASCADE)
#
#     def full(self):
#
#
#         return {
#             'id': self.id,
#             'name': self.name,
#             'description': self.desc,
#             'salary': self.salary
#         }
