from api.models import Ticket
from api.serializers import TicketSerializer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView


class TicketDetailAPIView(APIView):
    def get_object(self, ticket_id):
        try:
            return Ticket.objects.get(id=ticket_id)
        except Ticket.DoesNotExist as e:
            return Response({'error': str(e)})

    def get(self, request, ticket_id):
        ticket = self.get_object(ticket_id)
        serializer = TicketSerializer(ticket)
        return Response(serializer.data)

    def put(self, request, ticket_id):
        ticket = self.get_object(ticket_id)
        serializer = TicketSerializer(instance=ticket, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response({'error': serializer.errors})

    def delete(self, request, ticket_id):
        ticket = self.get_object(ticket_id)
        ticket.delete()
        return Response({'deleted': True})