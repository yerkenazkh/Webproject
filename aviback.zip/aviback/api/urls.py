from api.views.view_cbv import TicketDetailAPIView
from api.views.view_generic import CityDetailAPIView
from django.urls import path
# from api.views import company_list, comp_detail, vacancy_list, vacancy_detail, company_vacancy, top_ten
from api.views.view_fbv import ticket_list, cities_list

from rest_framework_jwt.views import obtain_jwt_token

urlpatterns = [
    path('login/', obtain_jwt_token),
    path('tickets/', ticket_list),
    path('tickets/<int:ticket_id>', TicketDetailAPIView.as_view()),
    path('cities/', cities_list),
    path('cities/<int:pk>', CityDetailAPIView.as_view()),
    # path('companies/<int:company_id>/vacancies', company_vacancy),
    # path('vacancies/top_ten', top_ten)
]
