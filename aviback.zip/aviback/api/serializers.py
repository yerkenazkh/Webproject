from rest_framework import serializers

from api.models import Ticket, City


# class VacancySerializer(serializers.Serializer):
#     id = serializers.IntegerField(read_only=True)
#     name = serializers.CharField()
#     salary = serializers.FloatField()
#     company_id = serializers.IntegerField()
#
#     def create(self, validated_data):
#         vacancy = Vacancy()
#         vacancy.name = validated_data.get('name')
#         vacancy.salary = validated_data.get('salary')
#         vacancy.company_id = validated_data.get('company_id')
#         vacancy.save()
#         return vacancy
#
#     def update(self, instance, validated_data):
#         instance.name = validated_data.get('name')
#         instance.salary = validated_data.get('salary')
#         instance.company_id = validated_data.get('company_id')
#         instance.save()
#         return instance


class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model = City
        fields = ('id', 'name', 'country', 'airport_name')


class TicketSerializer(serializers.ModelSerializer):
    from_city = CitySerializer(read_only=True)
    to_city = CitySerializer(read_only=True)

    class Meta:
        model = Ticket
        fields = ('id', 'from_city', 'to_city', 'price')


# class UserSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = User
#         fields = ('id', 'name', 'login', 'password')
